//
//  Hanabi_TrackerTests.swift
//  Hanabi TrackerTests
//
//  Created by Max Stephenson on 12/19/24.
//

import Testing
@testable import Hanabi_Tracker

struct Hanabi_TrackerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
